/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sqlex;

/**
 *
 * @author Administrator
 */
public class Sqlex {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
    }
    
    public void importCSVToDatabase(String src) throws Exception {
        java.io.BufferedReader in = new java.io.BufferedReader(new java.io.FileReader(src));
        String line=in.readLine();
        String hd[] = line.split(",");
        StringBuilder llsb = new StringBuilder();// ll = "";
        while((line=in.readLine())!=null){
            llsb.append(line);
            java.util.ArrayList<String> tmpArr = CSVLine2Arr(llsb.toString());
            if(tmpArr != null){
                System.out.println(tmpArr);
                llsb.setLength(0);
            }
        }
        in.close();
    }
    
    public java.util.ArrayList<String> CSVLine2Arr(String s){
        int bg = 0;
        int ed = 0;
        int ln = s.length();
        java.util.ArrayList<String> arr = new java.util.ArrayList<>();
        while(bg<ln){
            ed = s.indexOf(",", ed);
            if(ed<0){
                ed = ln;
            }
            int count=0;
            for(int i=bg; i<ed; i++){if(s.charAt(i)=='\"')count++;}
            if(count%2 == 0){
                String tmp = s.substring(bg, ed);
                if(tmp.startsWith("\"")){
                    tmp = tmp.substring(1, tmp.length()-1).replaceAll("\"\"", "\"");
                }
                arr.add(tmp);
                bg = ed+1;
                ed = bg;
            }
            else{
                if(ed >= ln){
                    return null;
                }
                ed++;
            }
        }
        return arr;
    }
    
}
