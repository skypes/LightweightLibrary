/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author Administrator
 */
public class EntityGenerator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        createEntityFile();
    }
    
    public static void createEntityFile() throws Exception {
        java.util.HashMap<String, String> paraMap = new java.util.HashMap<>();
        paraMap.put("ip", "???.???.???.???");
        paraMap.put("dbName", "dementia_tp");
        paraMap.put("uid", "newuser");
        paraMap.put("psswd", "?????");

        paraMap.put("schemaName", "dementia_tp");
        paraMap.put("packageName", "entity");
        paraMap.put("dest", "C:\\tmp\\entity");

        createEntityFile(paraMap);
        //System.Data.SqlClient.SqlConnection conn = getConnection(ip, dbName, uid, psswd);
        //listTables(dbName, schemaName, nameSpace, dest, conn);
        //conn.Close();
        //createEntityFile(ip, dbName, uid, psswd);
        //Dictionary<String, String> tbMap = new Dictionary<int, string>();
    }

    public static void createEntityFile(java.util.HashMap<String, String> paraMap) throws Exception {
        String ip = paraMap.get("ip");
        String dbName = paraMap.get("dbName");
        String uid = paraMap.get("uid");
        String psswd = paraMap.get("psswd");

        String schemaName = paraMap.get("schemaName");
        String packageName = paraMap.get("packageName");
        String dest = paraMap.get("dest");

        Class.forName("org.mariadb.jdbc.Driver");
                
        java.sql.Connection conn = getConnection(ip, dbName, uid, psswd);
        listTables(dbName, schemaName, packageName, dest, conn);
        conn.close();
        
    }

    public static void listTables(String dbName, String schemaName, String packageName, String dest, java.sql.Connection conn) throws Exception {
        String str = "show tables in "+ dbName;
        java.sql.Statement stmt = conn.createStatement();

        java.sql.ResultSet res = stmt.executeQuery(str);

//        java.util.ArrayList<String> columns = new java.util.ArrayList<>();
        java.util.ArrayList<String> tbList = new java.util.ArrayList<>();
        while (res.next()) {
            tbList.add(res.getString(1));
        }
        stmt.close();
//        System.out.println(tbList);
        java.io.File destDir = new java.io.File(dest);
        if (! destDir.exists()) {
            destDir.mkdirs();
        }
        for(String tn : tbList){
            createEntityFile(tn, packageName, schemaName, dest, conn);
        }
    }



    public static void createEntityFile(String tbName, String packageName, String schemaName, String dest, java.sql.Connection conn) throws Exception {
        String className = tbName.substring(0,1).toUpperCase() + tbName.substring(1).toLowerCase();
        System.out.println("Create entity file " + className + "...");

        String str = "desc "+schemaName+"."+tbName;
        
        java.sql.Statement stmt = conn.createStatement();
        java.sql.ResultSet res = stmt.executeQuery(str);

        java.io.FileWriter outputFile = new java.io.FileWriter(dest+"/"+className + ".java");
        outputFile.write("package "+packageName+";\n\n");
        outputFile.write("import db.*;\n\n");
        outputFile.write("public class " + className + " extends _table {\n");
        StringBuilder declaimSb = new StringBuilder();
        StringBuilder declaimfieldListSb = new StringBuilder();
        String tab = "";

        while (res.next()) {
            String fieldName = res.getString(1);
            String fieldType = res.getString(2);
            String dataType = "_str";
            if (fieldType.startsWith("date")) {
                dataType = "_date";
            }
            else if (fieldType.startsWith("float") ||
                     fieldType.startsWith("real"))
            {
                dataType = "_float";
            }
            else if (fieldType.startsWith("int") )
            {
                dataType = "_int";
            }
            outputFile.write("    public "+ dataType + " "+ fieldName + ";\n");
            declaimSb.append("        ").append(fieldName).append(" = new ").append(dataType).append("(\"").append(fieldName).append("\", this);\n");
            declaimfieldListSb.append(tab).append(fieldName);
            tab = ", ";
        }
        outputFile.write("\n    public "+ className + "() {\n\n");
        outputFile.write("        super(\"" + schemaName + "\", \""+ tbName + "\");\n\n");
        outputFile.write(declaimSb.toString());
        outputFile.write("\n        fieldList = new _field[] { " + declaimfieldListSb.toString()+ " };\n");
        outputFile.write("    }\n");
        outputFile.write("}\n");
        stmt.close();
        outputFile.close();

    }
    
    public static java.sql.Connection getConnection(String ip, String dbName, String uid, String psswd) throws Exception { 
//Connection connection = DriverManager.getConnection("jdbc:mariadb://localhost:3306/DB?user=root&password=myPassword");
        String connetionString = "jdbc:mariadb://"+ ip + ":3306/"+dbName+"?user="+ uid + "&password="+ psswd;
        java.sql.Connection cnn = java.sql.DriverManager.getConnection(connetionString);
        return cnn;
    }



    
}
