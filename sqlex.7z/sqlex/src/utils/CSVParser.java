/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author Administrator
 */
public class CSVParser {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        String dir = "C:\\tmp\\longtermcare\\data";
        String className = "entity";
//        new CSVParser().checkCSVProcess(dir);
        new CSVParser().createDBSchemaProcess(dir);
//        new CSVParser().createEntityFile();
//        db.Database rec = new db.Database(getConnection());
//        new CSVParser().importCSV(dir, className, rec);
        
    }
    
    public void checkCSVProcess(String dirn) throws Exception {
//        String dirn = "C:\\tmp\\delete\\longtermcare\\新北市\\ntpc_health";
        java.io.File dir = new java.io.File(dirn);
        for(java.io.File f:dir.listFiles()){
            if(f.getName().endsWith("csv")){
                checkCSV(f.toString());
            }
        }
    }
    
    public void createDBSchemaProcess(String dirn) throws Exception {
        java.util.HashMap<String, java.util.HashMap<String, String>> tableFieldTypeMap = new java.util.HashMap<>();
        java.io.File dir = new java.io.File(dirn);
        for(java.io.File f:dir.listFiles()){
            if(f.getName().endsWith("csv")){
                createDBSchemaByCSV(f.toString(), tableFieldTypeMap);
            }
        }
        
        java.util.HashMap<String, Integer> fnCountMap = new java.util.HashMap<>();
        
        for(String tn : tableFieldTypeMap.keySet()){
            java.util.HashMap<String, String> fieldTypeMap = tableFieldTypeMap.get(tn);
            for(String fn : fieldTypeMap.keySet()){
                fnCountMap.put(fn, (fnCountMap.get(fn)==null)?1:(fnCountMap.get(fn)+1));
            }
        }
        int totalTb = tableFieldTypeMap.size()/3;
        for(String tn : tableFieldTypeMap.keySet()){
            StringBuilder script = new StringBuilder();
            System.out.println("DROP TABLE IF EXISTS "+tn+";");
            script.append("CREATE TABLE ").append(tn).append("(");
            String tab = "\n";
            java.util.HashSet<String> indexFieldSet = new java.util.HashSet<>();
            java.util.HashMap<String, String> fieldTypeMap = tableFieldTypeMap.get(tn);
            for(String fn : fieldTypeMap.keySet()){
                String tp = fieldTypeMap.get(fn);
                script.append(tab).append("  ").append(fn).append(" ").append(tp);
                tab = ",\n";
//                fnCountMap.put(fn, (fnCountMap.get(fn)==null)?1:(fnCountMap.get(fn)+1));
                if(fnCountMap.get(fn) > totalTb){
                    indexFieldSet.add(fn);
//                    System.out.println(fn +" --> " +fnCountMap.get(fn));
                }
            }
            for(String idx : indexFieldSet){
                script.append(tab).append("  INDEX(").append(idx).append(")");
            }
            script.append("\n);\n");
            System.out.println(script.toString());
        }
        
    }
    
    public void createEntityFile(String className) throws Exception {
        java.util.HashMap<String, String> paraMap = new java.util.HashMap<>();
        paraMap.put("ip", "???.???.???.???");
        paraMap.put("dbName", "dementia_tp");
        paraMap.put("uid", "newuser");
        paraMap.put("psswd", "?????");

        paraMap.put("schemaName", "dementia_tp");
        paraMap.put("packageName", "entity");
        paraMap.put("dest", "C:\\tmp\\entity");

        EntityGenerator.createEntityFile(paraMap);
    }

    public void importCSV(String dirn, String className, db.Database rec) throws Exception {
//        db.Database rec = new db.Database(getConnection());
        java.io.File dir = new java.io.File(dirn);
        for(java.io.File f:dir.listFiles()){
            String fn = f.getName();
            if(fn.endsWith("csv")){
                String cn = fn.substring(0,1).toUpperCase()+fn.substring(1, fn.lastIndexOf("."));
                String fcn = className+"."+cn;
//                System.out.println("imtport "+fcn);
                Class C = Class.forName(fcn);
                java.lang.reflect.Constructor ctor = C.getConstructor();
                db._table T = (db._table)ctor.newInstance();
//                System.out.println("imtport "+T.ConventionalName());
                importCSVToDatabase(f.toString(), T, rec);
            }
        }
        
    }
    
    public void importCSVToDatabase(String src, db._table t, db.Database rec) throws Exception {
        System.out.println("import "+src);
//        db.Database rec = new db.Database(getConnection());
        rec.truncate(t);
        java.io.BufferedReader in = new java.io.BufferedReader(new java.io.FileReader(src));
        String line=in.readLine();
        StringBuilder sb = new StringBuilder();
        String hd[] = line.split(",");
        while((line=in.readLine())!=null){
            try{
                sb.append(line);
                java.util.ArrayList<String> tmpArr = CSVLine2Arr(sb.toString());
                if(tmpArr == null){
                    continue;
                }
                sb.setLength(0);
                java.util.HashMap<String, String> tmpMap = new java.util.HashMap<>();
                for(int i=0; i<tmpArr.size(); i++){
                    tmpMap.put(hd[i], tmpArr.get(i));
                }
                utils.Entity.importTable(t, tmpMap);
                rec.insert(t);
            }
            catch(Exception e){
                System.out.println(line);
                System.out.println(db._sqlExpress.getInsertSql(t));
                System.out.println(e.toString());
            }
        }
        in.close();
    }
    
    public void checkCSV(String src) throws Exception {
        System.out.println("Check "+src);
        java.io.BufferedReader in = new java.io.BufferedReader(new java.io.FileReader(src));
        String line=in.readLine();
        String hd[] = line.split(",");
        StringBuilder sb = new StringBuilder(); // lline = "";
        while((line=in.readLine())!=null){
            sb.append(line);
            java.util.ArrayList<String> tmpArr = CSVLine2Arr(sb.toString());
            if(tmpArr == null){
                continue;
            }
            if(tmpArr.size() != hd.length){
                System.err.println("Wrong CSV format in file "+src);
                System.err.println(hd.length+" : "+tmpArr.size());
                System.err.println(tmpArr);
            }
            sb.setLength(0);
        }
        in.close();
    }
    
    public void createDBSchemaByCSV(String src) throws Exception {
        java.io.File f = new java.io.File(src);
        String tbName = f.getName().substring(0, f.getName().lastIndexOf("."));
        StringBuilder script = new StringBuilder();
        System.out.println("DROP TABLE IF EXISTS "+tbName+";");
        script.append("CREATE TABLE ").append(tbName).append("(");
        java.io.BufferedReader in = new java.io.BufferedReader(new java.io.FileReader(src));
        String line=in.readLine();
        String hd[] = line.replaceAll("[^0-9A-Za-z_,]", "").split(",");
        java.util.HashMap<String, java.util.HashMap<String, Integer>> fieldTypeCountmap = new java.util.HashMap<>();
        java.util.HashMap<String, Integer> fieldLenghmap = new java.util.HashMap<>();
        StringBuilder sb = new StringBuilder(); // lline = "";
        while((line=in.readLine())!=null){
            sb.append(line);
            java.util.ArrayList<String> tmpArr = CSVLine2Arr(sb.toString());
            if(tmpArr == null){
                continue;
            }
            if(tmpArr.size() != hd.length){
                System.err.println("Wrong CSV format in file "+src);
                System.err.println(hd.length+" : "+tmpArr.size());
                System.err.println(tmpArr);
            }
            for(int i=0; i<tmpArr.size(); i++){
                int lenth = tmpArr.get(i).getBytes().length;
                fieldLenghmap.put(hd[i], fieldLenghmap.containsKey(hd[i])?Math.max(lenth, fieldLenghmap.get(hd[i])):lenth);
                java.util.HashMap<String, Integer> typeCountmap = fieldTypeCountmap.get(hd[i]);
                if(typeCountmap == null){
                    fieldTypeCountmap.put(hd[i], typeCountmap=new java.util.HashMap<>());
                }
                String pt = tmpArr.get(i).trim();
                if(!pt.isEmpty()){
                    if(pt.matches("[0-9]+")){
                        typeCountmap.put("INT", typeCountmap.containsKey("INT")?typeCountmap.get("INT")+1:1);
                    }
                    else if(pt.matches("[0-9]+\\-[0-9]+\\-[0-9]+(| [0-9]+:[0-9]+:[0-9]+(|\\.[0-9]+))")){
                        typeCountmap.put("DATE", typeCountmap.containsKey("DATE")?typeCountmap.get("DATE")+1:1);
                    }
                    else{
                        typeCountmap.put("VARCHAR", typeCountmap.containsKey("VARCHAR")?typeCountmap.get("VARCHAR")+1:1);
                    }
                }
            }
            sb.setLength(0);
        }
        in.close();
        String tab = "\n";
        for(String fd:hd){
            java.util.HashMap<String, Integer> typeCountmap = fieldTypeCountmap.get(fd);
            int maxtp = -1;
            String tp = "VARCHAR";
            for(String s:typeCountmap.keySet()){
                if(maxtp < typeCountmap.get(s)){
                    maxtp = typeCountmap.get(s);
                    tp = s;
                }
            }
            if((tp.equals("INT") && fieldLenghmap.get(fd) > 10) || typeCountmap.size() != 1){
                tp = "VARCHAR";
            }
            if(tp.equals("DATE") | tp.equals("INT")){
                script.append(tab).append("  ").append(fd).append(" ").append(tp);
            }
            else{
                script.append(tab).append("  ").append(fd).append(" ").append(tp).append("(").append(fieldLenghmap.get(fd)).append(")");
            }
            tab = ",\n";
        }
        script.append("\n);\n");
        System.out.println(script.toString());
    }
    
    
    public void createDBSchemaByCSV(String src, java.util.HashMap<String, java.util.HashMap<String, String>> tableFieldTypeMap) throws Exception {
        java.io.File f = new java.io.File(src);
        String tbName = f.getName().substring(0, f.getName().lastIndexOf("."));
        java.util.HashMap<String, String> fieldTypeMap = new java.util.HashMap<>();
        tableFieldTypeMap.put(tbName, fieldTypeMap);
        java.io.BufferedReader in = new java.io.BufferedReader(new java.io.FileReader(src));
        String line=in.readLine();
        String hd[] = line.replaceAll("[^0-9A-Za-z_,]", "").split(",");
        java.util.HashMap<String, java.util.HashMap<String, Integer>> fieldTypeCountmap = new java.util.HashMap<>();
        java.util.HashMap<String, Integer> fieldLenghmap = new java.util.HashMap<>();
        StringBuilder sb = new StringBuilder(); // lline = "";
        while((line=in.readLine())!=null){
            sb.append(line);
            java.util.ArrayList<String> tmpArr = CSVLine2Arr(sb.toString());
            if(tmpArr == null){
                continue;
            }
            if(tmpArr.size() != hd.length){
                System.err.println("Wrong CSV format in file "+src);
                System.err.println(hd.length+" : "+tmpArr.size());
                System.err.println(tmpArr);
            }
            for(int i=0; i<tmpArr.size(); i++){
                int lenth = tmpArr.get(i).getBytes().length;
                fieldLenghmap.put(hd[i], fieldLenghmap.containsKey(hd[i])?Math.max(lenth, fieldLenghmap.get(hd[i])):lenth);
                java.util.HashMap<String, Integer> typeCountmap = fieldTypeCountmap.get(hd[i]);
                if(typeCountmap == null){
                    fieldTypeCountmap.put(hd[i], typeCountmap=new java.util.HashMap<>());
                }
                String pt = tmpArr.get(i).trim();
                if(!pt.isEmpty()){
                    if(pt.matches("[0-9]+")){
                        typeCountmap.put("INT", typeCountmap.containsKey("INT")?typeCountmap.get("INT")+1:1);
                    }
                    else if(pt.matches("[0-9]+\\-[0-9]+\\-[0-9]+(| [0-9]+:[0-9]+:[0-9]+(|\\.[0-9]+))")){
                        typeCountmap.put("DATE", typeCountmap.containsKey("DATE")?typeCountmap.get("DATE")+1:1);
                    }
                    else{
                        typeCountmap.put("VARCHAR", typeCountmap.containsKey("VARCHAR")?typeCountmap.get("VARCHAR")+1:1);
                    }
                }
            }
            sb.setLength(0);
        }
        in.close();
//        String tab = "\n";
        for(String fd:hd){
            java.util.HashMap<String, Integer> typeCountmap = fieldTypeCountmap.get(fd);
            int maxtp = -1;
            String tp = "VARCHAR";
            for(String s:typeCountmap.keySet()){
                if(maxtp < typeCountmap.get(s)){
                    maxtp = typeCountmap.get(s);
                    tp = s;
                }
            }
            if((tp.equals("INT") && fieldLenghmap.get(fd) > 10) || typeCountmap.size() != 1){
                tp = "VARCHAR";
            }
            if(tp.equals("DATE") | tp.equals("INT")){
                fieldTypeMap.put(fd, tp);
            }
            else{
                fieldTypeMap.put(fd, tp+"("+(fieldLenghmap.get(fd)+10)+")");
            }
        }
    }
    
    public java.util.ArrayList<String> CSVLine2Arr(String s){
        int bg = 0;
        int ed = 0;
        int ln = s.length();
        java.util.ArrayList<String> arr = new java.util.ArrayList<>();
        while(bg <= ln){
            ed = s.indexOf(",", ed);
            if(ed<0){
                ed = ln;
            }
            int count=0;
            for(int i=bg; i<ed; i++){if(s.charAt(i)=='\"')count++;}
            if(count%2 == 0){
                String tmp = s.substring(bg, ed);
                if(tmp.startsWith("\"")){
                    tmp = tmp.substring(1, tmp.length()-1).replaceAll("\"\"", "\"").replaceAll("\\\\", "\\\\\\\\");
                }
                arr.add(tmp.replaceAll("\\\\", "\\\\\\\\"));
                bg = ed+1;
                ed = bg;
            }
            else{
                if(ed >= ln){
                    return null;
                }
                ed++;
            }
        }
        return arr;
    }
    
    public static java.sql.Connection getConnection() throws Exception { 
        
        java.util.HashMap<String, String> paraMap = new java.util.HashMap<>();
        paraMap.put("ip", "???.???.???.???");
        paraMap.put("dbName", "dementia_tp");
        paraMap.put("uid", "newuser");
        paraMap.put("psswd", "????????");
                
        String ip = paraMap.get("ip");
        String dbName = paraMap.get("dbName");
        String uid = paraMap.get("uid");
        String psswd = paraMap.get("psswd");
        
        String connetionString = "jdbc:mariadb://"+ ip + ":3306/"+dbName+"?user="+ uid + "&password="+ psswd;
        java.sql.Connection cnn = java.sql.DriverManager.getConnection(connetionString);
        return cnn;
    }
    
}
