/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author Administrator
 */
public class EntityGenerator4MSSQL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        createEntityFile();
    }
    
    public static void createEntityFile() throws Exception {
        java.util.HashMap<String, String> paraMap = new java.util.HashMap<>();
        paraMap.put("ip", "???.???.???.???");
        paraMap.put("dbName", "menagerie");
        paraMap.put("uid", "nosqluser");
        paraMap.put("psswd", "?????");

        paraMap.put("schemaName", "menagerie.dbo");
        paraMap.put("nameSpace", "sqlex.examples.menagerie2");
        paraMap.put("dest", "C:\\tmp\\entity");

        createEntityFile(paraMap);
        //System.Data.SqlClient.SqlConnection conn = getConnection(ip, dbName, uid, psswd);
        //listTables(dbName, schemaName, nameSpace, dest, conn);
        //conn.Close();
        //createEntityFile(ip, dbName, uid, psswd);
        //Dictionary<String, String> tbMap = new Dictionary<int, string>();
    }

    public static void createEntityFile(java.util.HashMap<String, String> paraMap) throws Exception {
        String ip = paraMap.get("ip");
        String dbName = paraMap.get("dbName");
        String uid = paraMap.get("uid");
        String psswd = paraMap.get("psswd");

        String schemaName = paraMap.get("schemaName");
        String nameSpace = paraMap.get("nameSpace");
        String dest = paraMap.get("dest");

        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//        Class.forName("com.mysql.jdbc.Driver").newInstance();
//        java.sql.Connection conn = java.sql.DriverManager.getConnection(url);
        java.sql.Connection conn = getConnection(ip, dbName, uid, psswd);
        listTables(dbName, schemaName, nameSpace, dest, conn);
        conn.close();
        //createEntityFile(ip, dbName, uid, psswd);
    }

    public static void listTables(String dbName, String schemaName, String nameSpace, String dest, java.sql.Connection conn) throws Exception {
        //System.Data.SqlClient.SqlConnection conn = getConnection();
        String str = "SELECT TABLE_NAME FROM "+ dbName + ".INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE'";
        java.sql.Statement stmt = conn.createStatement();

//        System.Data.SqlClient.SqlDataReader reader = command.ExecuteReader();
        java.sql.ResultSet res = stmt.executeQuery(str);

        java.util.ArrayList<String> columns = new java.util.ArrayList<>();
        java.util.ArrayList<String> tbList = new java.util.ArrayList<>();
//        var columns = new List<string>();
//        List<String> tbList = new List<String>();
        while (res.next()) {
            tbList.add(res.getString(1));
            //Console.WriteLine("Writing... "+reader[0].ToString());
            //createEntityFile(reader[0].ToString(), nameSpace, conn);
            //break;
        }
        stmt.close();
        java.io.File destDir = new java.io.File(dest);
        if (! destDir.exists()) {
            destDir.mkdirs();
        }
        //conn.Close();
        for(String tn : tbList){
            createEntityFile(tn, nameSpace, schemaName, dest, conn);
        }
    }



    public static void createEntityFile(String tbName, String nameSpace, String schemaName, String dest, java.sql.Connection conn) throws Exception {
        String className = tbName.substring(0,1).toUpperCase() + tbName.substring(1).toLowerCase();
        System.out.println("Create entity file " + className + "...");
        //System.Data.SqlClient.SqlConnection conn = getConnection(ip, dbName, uid, psswd);
        String str = "SELECT c.Name, t.Name, t.max_length " +
                     "  FROM sys.columns c " +
                     " INNER JOIN sys.objects o ON o.object_id = c.object_id " +
                     "  LEFT JOIN  sys.types t on t.user_type_id = c.user_type_id " +
                     " WHERE o.type = 'U' " +
                     "   AND o.Name = '"+ tbName + "' " +
                     " ORDER BY o.Name, c.Name; ";
        
        java.sql.Statement stmt = conn.createStatement();
        java.sql.ResultSet res = stmt.executeQuery(str);
//        System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(str, conn);
//        System.Data.SqlClient.SqlDataReader reader = command.ExecuteReader();

        java.io.FileWriter outputFile = new java.io.FileWriter(dest+"/"+className + ".java");
        outputFile.write("package exercise.entity;\n\n");
        outputFile.write("import db.*;\n\n");
        outputFile.write("public class " + className + " extends _table {\n");
        StringBuilder declaimSb = new StringBuilder();
        StringBuilder declaimfieldListSb = new StringBuilder();
        String tab = "";

        while (res.next()) {
            String fieldName = res.getString(1);
            String fieldType = res.getString(2);
            String dataType = "_str";
            if (fieldType.startsWith("date")) {
                dataType = "_date";
            }
            else if (fieldType.startsWith("float") ||
                     fieldType.startsWith("real"))
            {
                dataType = "_float";
            }
            else if (fieldType.startsWith("int") )
            {
                dataType = "_int";
            }
            outputFile.write("    public "+ dataType + " "+ fieldName + ";\n");
            declaimSb.append("        ").append(fieldName).append(" = new ").append(dataType).append("(\"").append(fieldName).append("\", this);\n");
            declaimfieldListSb.append(tab).append(fieldName);
            tab = ", ";
        }
        outputFile.write("\n    public "+ className + "() {\n\n");
        outputFile.write("        super(\"" + schemaName + "\", \""+ className + "\");\n\n");
        outputFile.write(declaimSb.toString());
        outputFile.write("\n        fieldList = new _field[] { " + declaimfieldListSb.toString()+ " };\n");
        outputFile.write("    }\n");
        outputFile.write("}\n");
        stmt.close();
        outputFile.close();

    }

    // IP: 10.64.17.130
    // Database Name: menagerie
    // user ID: nosqluser
    // Password: nosql123
    public static java.sql.Connection getConnection(String ip, String dbName, String uid, String psswd) throws Exception { 
//        connetionString = "Data Source="+ ip + ";Initial Catalog="+ dbName + "; User ID="+ uid + ";Password="+ psswd;
//con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=database;user=user;password=password;");
        String connetionString = "jdbc:sqlserver://"+ ip + ":1433;databaseName="+dbName+";user="+ uid + ";password="+ psswd;
        java.sql.Connection cnn = java.sql.DriverManager.getConnection(connetionString);
        return cnn;
    }



    
}
