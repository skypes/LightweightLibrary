/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author Administrator
 */
public class Entity {
    
    public static void importTable(db._table tb, java.util.HashMap<String, String> map){
        for(db._field f:tb.fieldList){
            f.val = null;
            if(map.containsKey(f.field)){
                f.setValue(map.get(f.field));
            }
        }
    }
    
    public static void cleanTable(db._table tb){
        for(db._field f:tb.fieldList){
            f.val = null;
        }
    }
    
}
