/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise;

/**
 *
 * @author Administrator
 */
public class Exercise_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
//        new Exercise_1().createEntityClass();
//        new Exercise_1().DELETE_exercise();
//        new Exercise_1().SELECT_exercise();
        new Exercise_1().SELECT_join_tables_exercise();
    }
    
    public void createEntityClass() throws Exception {
        java.util.HashMap<String, String> paraMap = new java.util.HashMap<>();
        paraMap.put("ip", "???.???.???.???");
        paraMap.put("dbName", "menagerie");
        paraMap.put("uid", "newuser");
        paraMap.put("psswd", "mysql");

        paraMap.put("schemaName", "menagerie");
        paraMap.put("packageName", "entity");
        paraMap.put("dest", "C:\\tmp\\entity");

        utils.EntityGenerator.createEntityFile(paraMap);
    }
    
    public void SELECT_exercise() throws Exception {
        db.Database rec = new db.Database(getConnection());
        entity.Pet pet = new entity.Pet();
        rec.select(pet).fetch();
        while(rec.next()){
            System.out.println(pet.name.value()+"\t"+pet.owner.value()+"\t"+pet.birth.value()+"\t"+pet.death.value());
        }
        rec.close();
    }
    
    public void SELECT_rage_exercise() throws Exception {
        db.Database rec = new db.Database(getConnection());
        entity.Pet pet = new entity.Pet();
        rec.select(pet).fetch(2,200);
        while(rec.next()){
            System.out.println(pet.name.value()+"\t"+pet.owner.value()+"\t"+pet.birth.value()+"\t"+pet.death.value());
        }
        rec.close();
    }
    
    public void SELECT_join_tables_exercise() throws Exception {
        db.Database rec = new db.Database(getConnection());
        entity.Pet pet = new entity.Pet();
        entity.Event event = new entity.Event();
        db._field fields[] = new db._field[]{pet.name, pet.owner, event.date, event.remark};
        rec.select(fields).where(pet.name.equal(event.name)).fetch();
        while(rec.next()){
            System.out.println(pet.name.value()+"\t"+pet.owner.value()+"\t"+event.date.value()+"\t"+event.remark.value());
        }
        rec.close();
    }
    
    public void INSERT_exercise() throws Exception {
        db.Database rec = new db.Database(getConnection());
        entity.Pet pet = new entity.Pet();
        pet.name.value("Fluffy_2");
        pet.owner.value("Harold_2");
        pet.species.value("cat");
        pet.sex.value("f");
        pet.birth.value(new java.util.Date());
        rec.insert(pet);
        rec.close();
    }
    
    public void UPDATE_exercise() throws Exception {
        db.Database rec = new db.Database(getConnection());
        entity.Pet pet = new entity.Pet();
        pet.death.value(new java.util.Date());
        rec.update(pet, pet.name.equal("Buffy").and(pet.owner.equal("Harold")));
        rec.close();
    }
    
    public void DELETE_exercise() throws Exception {
        db.Database rec = new db.Database(getConnection());
        entity.Pet pet = new entity.Pet();
        pet.death.value(new java.util.Date());
//        System.out.println(db._sqlExpress.getDeleteSql(pet, pet.name.equal("Buffy").and(pet.owner.equal("Harold"))));
        rec.delete(pet.name.equal("Fluffy_2").and(pet.owner.equal("Harold_2")));
        rec.close();
    }
    
    public static java.sql.Connection getConnection() throws Exception { 
        
        java.util.HashMap<String, String> paraMap = new java.util.HashMap<>();
        paraMap.put("ip", "???.???.???.???");
        paraMap.put("dbName", "menagerie");
        paraMap.put("uid", "newuser");
        paraMap.put("psswd", "mysql");
                
        String ip = paraMap.get("ip");
        String dbName = paraMap.get("dbName");
        String uid = paraMap.get("uid");
        String psswd = paraMap.get("psswd");
        
        String connetionString = "jdbc:mariadb://"+ ip + ":3306/"+dbName+"?user="+ uid + "&password="+ psswd;
        java.sql.Connection cnn = java.sql.DriverManager.getConnection(connetionString);
        return cnn;
    }
    
}
