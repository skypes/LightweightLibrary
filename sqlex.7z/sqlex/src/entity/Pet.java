package entity;

import db.*;

public class Pet extends _table {
    public _str name;
    public _str owner;
    public _str species;
    public _str sex;
    public _date birth;
    public _date death;

    public Pet() {

        super("menagerie", "Pet");

        name = new _str("name", this);
        owner = new _str("owner", this);
        species = new _str("species", this);
        sex = new _str("sex", this);
        birth = new _date("birth", this);
        death = new _date("death", this);

        fieldList = new _field[] { name, owner, species, sex, birth, death };
    }
}
