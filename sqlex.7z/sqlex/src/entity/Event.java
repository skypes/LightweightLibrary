package entity;

import db.*;

public class Event extends _table {
    public _str name;
    public _date date;
    public _str type;
    public _str remark;

    public Event() {

        super("menagerie", "Event");

        name = new _str("name", this);
        date = new _date("date", this);
        type = new _str("type", this);
        remark = new _str("remark", this);

        fieldList = new _field[] { name, date, type, remark };
    }
}
