/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

/**
 *
 * @author Administrator
 */
public class _field {
    
    public Object val = null;
    public String field = null;
    public _table table = null;
    public _fieldToken token;

    //public _field(String field, _table table) {
    //    this.table = table;
    //    this.field = field;
    //    token = new _defaultToken();
    //}

    public _field(String field, _table table, _fieldToken token) {
        this.table = table;
        this.field = field;
        this.token = token;
    }

    public _field(String field, _table table) {
        this.table = table;
        this.field = field;
    }

    public String valueString()
    {
        if (val == null) {
            return "";
        }
        return val.toString();
    }
    
    public void setValue(String v){
        token.setValue(v, this);
    }

    public String valueToken() {
        return token.getValueToken(this);
    }

    public String selectToken(String tableAlias) {
        return token.selectAlias(this, tableAlias);
    }

    public String selectToken() {
        return token.selectAlias(this);
    }

    public _expr equal(_field f) {
        return new _expr(this, "=", f);
    }
    public _expr notEqual(_field f) {
        return new _expr(this, "!=", f);
    }
    public _expr great(_field f) {
        return new _expr(this, ">", f);
    }
    public _expr greatEqual(_field f) {
        return new _expr(this, ">=", f);
    }
    public _expr less(_field f) {
        return new _expr(this, "<", f);
    }
    public _expr lessEqual(_field f) {
        return new _expr(this, "<=", f);
    }

    public _expr isNull() {
        return new _expr(this, "IS NULL");
    }

    public _expr isNotNull() {
        return new _expr(this, "IS NOT NULL");
    }

    public interface _fieldToken {
        String getValueToken(_field f);
        String selectAlias(_field f, String tableAlias);
        String selectAlias(_field f);
        void setValue(String v, _field f);
    }

    public class _defaultToken implements _fieldToken {
        public String getValueToken(_field f) {
            if (f.val == null) {
                return "NULL";
            }
            //return "'" + f.val.ToString().Replace("'", "''") + "'";
            return "'" + ((String)(f.val)).replaceAll("'", "''") + "'";
        }
        public String selectAlias(_field f, String tableAlias)  {
            return tableAlias + "." + f.field;
        }
        public String selectAlias(_field f) {
            return f.field;
        }
        public void setValue(String v, _field f){
            f.val = v;
        }
    }

    public _int counter() {
        _int f = new _int(this.field, this.table, new _countToken());
        return f;
    }

    public class _countToken implements _fieldToken {
        public String getValueToken(_field f) {
            if (f.val == null) {
                return "NULL";
            }
            return "'" + f.val + "'";
        }
        public String selectAlias(_field f, String tableAlias) {
            return "COUNT(*)";
        }
        public String selectAlias(_field f) {
            return "COUNT(*)";
        }
        public void setValue(String v, _field f){
//            f.val = v;
        }
    }


    public _int custom(String fn) {
        _int f = new _int(this.field, this.table, new _customToken(fn));
        return f;
    }

    public class _customToken implements _fieldToken {
        String fn;

        public _customToken(String fn) {
            this.fn = fn;
        }

        public String getValueToken(_field f) {
            if (f.val == null) {
                return "NULL";
            }
            return f.val.toString();
        }
        public String selectAlias(_field f, String tableAlias) {
            return fn + "(" + tableAlias + "." + f.field + ")";
        }
        public String selectAlias(_field f) {
            return fn + "(" + f.field + ")";
        }
        public void setValue(String v, _field f){
//            f.val = v;
        }
    }

}
