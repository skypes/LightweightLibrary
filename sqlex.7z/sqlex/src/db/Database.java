/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

/**
 *
 * @author Administrator
 */
public class Database {
    
    _sqlExpress sqlExpr;
    java.sql.Connection conn;
    java.sql.Statement stmt;
    java.sql.ResultSet res;
        //System.Data.SqlClient.SqlCommand cmd;
//        System.Data.SqlClient.SqlDataReader reader;

    public static int counter = 0;

    public Database(java.sql.Connection conn) throws Exception {
        this.conn = conn;
        stmt = conn.createStatement();
        counter++;
    }

    public void fetch() throws Exception {
        res = stmt.executeQuery(sqlExpr.toSqlString());
    }

    public void fetch(int begin, int end) throws Exception {
        //System.Console.WriteLine(sqlExpr.toSqlString());
        res = stmt.executeQuery(sqlExpr.toSqlString(begin, end));
    }

    public boolean next() throws Exception {
        if (res.next()) {
            for (int i = 0; i < sqlExpr.fieldList.length; i++) {
                sqlExpr.fieldList[i].val = res.getObject(i+1);
                if (res.wasNull()) {
                    sqlExpr.fieldList[i].val = null;
                }
            }
            return true;
        }
        return false;
    }

    public void close() throws Exception {
        conn.close();
        counter--;
    }

    public void insert(_table t) throws Exception {
        stmt.executeUpdate(_sqlExpress.getInsertSql(t));
    }

    public void update(_table t, _expr e) throws Exception {
//        System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(_sqlExpress.getUpdateSql(t, e), conn);
//        cmd.ExecuteNonQuery();
        stmt.executeUpdate(_sqlExpress.getUpdateSql(t, e));
    }

    public void updateWithNull(_table t, _expr e) throws Exception {
//        System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(_sqlExpress.getUpdateSqlWithNull(t, e), conn);
//        cmd.ExecuteNonQuery();
        stmt.executeUpdate(_sqlExpress.getUpdateSqlWithNull(t, e));
    }

    public void delete(_expr e) throws Exception {
//        System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(_sqlExpress.getDeleteSql(t, e), conn);
//        cmd.ExecuteNonQuery();
        stmt.executeUpdate(_sqlExpress.getDeleteSql(e));
    }
    
    public void truncate(_table t) throws Exception {
        stmt.executeUpdate(_sqlExpress.getTruncateSql(t));
    }

    public Database select(_field[] fList) {
        sqlExpr = new _sqlExpress();
        sqlExpr.select(fList, false);
        return this;
    }

    public Database select(_field f) {
        sqlExpr = new _sqlExpress();
        sqlExpr.select(new _field[] { f }, false);
        return this;
    }

    public Database selectDistinct(_field[] fList) {
        sqlExpr = new _sqlExpress();
        sqlExpr.select(fList, true);
        return this;
    }

    public Database select(_table t) {
        sqlExpr = new _sqlExpress();
        sqlExpr.select(t.fieldList, false);
        return this;
    }

    public Database select(_table[] tList) {
        int numOfField = 0;
        for (int i=0; i<tList.length; i++) {
            numOfField += tList[i].fieldList.length;
        }
        _field[] fList = new _field[numOfField];
        int ptr = 0;
        for (int i = 0; i < tList.length; i++) {
            for (int j = 0; j < tList[i].fieldList.length; j++) {
                fList[ptr] = tList[i].fieldList[j];
                ptr++;
            }
        }
        sqlExpr = new _sqlExpress();
        sqlExpr.select(fList, false);
        return this;
    }

    public Database from(_table t) {
        sqlExpr.from(t);
        return this;
    }

    public Database innerJoin(_table t, _expr e) {
        sqlExpr.innerJoin(t,e);
        return this;
    }

    public Database leftJoin(_table t, _expr e) {
        sqlExpr.leftJoin(t, e);
        return this;
    }

    public Database where(_expr e1) {
        sqlExpr.where(e1);
        return this;
    }

    public Database groupBy(_field f) {
        sqlExpr.groupBy(new _field[] { f });
        return this;
    }

    public Database groupBy(_field[] fList) {
        sqlExpr.groupBy(fList);
        return this;
    }

    public Database orderBy(_field f) {
        //sqlExpr = new _sqlExpress();
        sqlExpr.orderBy(f, false);
        return this;
    }

    public Database orderBy(_field[] fList)   {
        boolean[] isDesc = new boolean[fList.length];
        //sqlExpr = new _sqlExpress();
        sqlExpr.orderBy(fList, isDesc);
        return this;
    }

    public Database orderBy(_field[] fList, boolean[] isDesc)  { 
        //sqlExpr = new _sqlExpress();
        sqlExpr.orderBy(fList, isDesc);
        return this;
    }

    public Database orderByDESC(_field f) {
        //sqlExpr = new _sqlExpress();
        sqlExpr.orderBy(f, true);
        return this;
    }

    public String toSqlString() throws Exception {
        return sqlExpr.toSqlString();
    }

    public String toSqlString(int begin, int end) throws Exception {
        return sqlExpr.toSqlString(begin, end);
    }

    public String toSqlDelteString(_expr e) {
        return _sqlExpress.getDeleteSql(e);
    }

    public String toSqlInsertString(_table t) {
        return _sqlExpress.getInsertSql(t);
    }

    public String toSqlUpdateString(_table t, _expr e) {
        return _sqlExpress.getUpdateSql(t, e);
    }
        
}
