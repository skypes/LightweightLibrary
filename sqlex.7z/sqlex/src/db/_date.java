/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

/**
 *
 * @author Administrator
 */
public class _date extends _field {

    public _date(String field, _table table) {
        super(field, table);
        this.token = new _dateToken();
    }

    public void value(java.util.Date o) {
        val = o;
    }

    public java.util.Date value() {
        return (java.util.Date)val;
    }

    public _expr equal(java.util.Date v) {
        return new _expr(this, " = '" + dateToStr(v) + "'");
    }
    public _expr notEqual(java.util.Date v) {
        return new _expr(this, " != '" + dateToStr(v) + "'");
    }
    public _expr great(java.util.Date v) {
        return new _expr(this, " > '" + dateToStr(v) + "'");
    }
    public _expr greatEqual(java.util.Date v) {
        return new _expr(this, " >= '" + dateToStr(v) + "'");
    }
    public _expr less(java.util.Date v) {
        return new _expr(this, " < '" + dateToStr(v) + "'");
    }
    public _expr lessEqual(java.util.Date v) {
        return new _expr(this, " <= '" + dateToStr(v) + "'");
    }
    public _expr between(java.util.Date v1, java.util.Date v2) {
        return new _expr(this, " BETWEEN '" + dateToStr(v1) + "' AND '" + dateToStr(v2) + "'");
    }

    public static String dateToStr(java.util.Date d){
        return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new java.util.Locale("en","US")).format(d);
    }

    public static java.util.Date strToDate(String s) throws Exception{
        if(s.matches("[0-9]+/[0-9]+/[0-9]+")){
            return new java.text.SimpleDateFormat("yyyy/MM/dd", new java.util.Locale("en","US")).parse(s);
        }
        else if(s.matches("[0-9]+-[0-9]+-[0-9]+")){
            return new java.text.SimpleDateFormat("yyyy-MM-dd", new java.util.Locale("en","US")).parse(s);
        }
        else if(s.matches("[0-9]+-[0-9]+-[0-9]+ [0-9]+:[0-9]+:[0-9]+")){
            return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", new java.util.Locale("en","US")).parse(s);
        }
        return null;
    }
    
    public class _dateToken implements _fieldToken {
        public String getValueToken(_field f) {
//            System.out.println("4444444444 --- > "+f.val);
            if (f.val == null) {
                return "NULL";
            }
            return "'" + dateToStr((java.util.Date)f.val) + "'";
        }
        public String selectAlias(_field f, String tableAlias)  {
            return tableAlias + "." + f.field;
        }
        public String selectAlias(_field f)  {
            return f.field;
        }
        public void setValue(String v, _field f){
            try{
                if(v==null){
                    f.val = null;
                }
                else{
                    f.val = strToDate(v);
                }
            }
            catch(Exception e){
                f.val = null;
                System.err.println(e.toString());
            }
        }
    }

//    public _int untilThisYear() {
//        _int f = new _int(this.field, this.table, new _untilThisYear()) ;
//        return f;
//    }
//
//    public class _untilThisYear implements _fieldToken {
//        public String getValueToken(_field f) {
//            if (f.val == null) {
//                return "NULL";
//            }
//            return dateToStr((java.util.Date)f.val); //f.val.ToString();
//        }
//        public String selectAlias(_field f, String tableAlias) {
//            return "DATEDIFF(YYYY, "+ tableAlias +"."+ f.field + ", GETDATE())";
//        }
//        public String selectAlias(_field f) {
//            return "DATEDIFF(YYYY, " + f.field + ", GETDATE())";
//        }
//    }

    public _int month() {
        _int f = new _int(this.field, this.table, new _customToken("MONTH"));
        return f;
    }

    public static boolean isDate(String dateStr) {
        return dateStr.matches("(^[0-9]{4}\\-[0-9]{2}\\-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}$)|(^[0-9]{4}\\-[0-9]{2}\\-[0-9]{2}$)");
    }
}
