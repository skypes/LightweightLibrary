/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

/**
 *
 * @author Administrator
 */
public class _int extends _field {
    
    public _int(String field, _table table) {
        super(field, table);
        this.token = new _intToken();
    }

    public _int(String field, _table table, _fieldToken customToken) {
        super(field, table, customToken);
    }

    public void value(Integer o) {
        //Console.WriteLine(o);
        val = o;
    }

    public Integer value() {
        return (Integer)val;
    }

    //public new String valueToken() {
    //    if (val == null) {
    //        return "NULL";
    //    }
    //    return val.ToString();
    //}

    public _expr equal(int v) {
        return new _expr(this, " = " + v);
    }
    public _expr notEqual(int v) {
        return new _expr(this, " != " + v);
    }
    public _expr great(int v) {
        return new _expr(this, " > " + v);
    }
    public _expr greatEqual(int v) {
        return new _expr(this, " >= " + v);
    }
    public _expr less(int v) {
        return new _expr(this, " < " + v);
    }
    public _expr lessEqual(int v) {
        return new _expr(this, " <= " + v);
    }

    public _expr between(int v1, int v2) {
        return new _expr(this, " BETWEEN " + v1 + " AND " + v2);
    }

    public class _intToken implements _fieldToken {
        public String getValueToken(_field f) {
            if (f.val == null) {
                return "NULL";
            }
            return f.val.toString();
        }
        public String selectAlias(_field f, String tableAlias) {
            return tableAlias + "." + f.field;
        }
        public String selectAlias(_field f) {
            return f.field;
        }
        public void setValue(String v, _field f){
            if(v==null || v.isEmpty()){
                f.val = null;
            }
            else{
                f.val = Double.valueOf(v);
            }
        }
    }

    public _int max() {
        _int f = new _int(this.field, this.table, new _customToken("MAX"));
        return f;
    }

    public _int min()  {
        _int f = new _int(this.field, this.table, new _customToken("MIN"));
        return f;
    }

    public static boolean isInt(String intStr) {
//        System.Text.RegularExpressions.Regex rgxInt = new System.Text.RegularExpressions.Regex("^[0-9]+$");
//        return rgxInt.IsMatch(intStr);
        return intStr.matches("^[0-9]+$");
    }
}
