/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

/**
 *
 * @author Administrator
 */
public class _float extends _field {
    
    public _float(String field, _table table) {
        super(field, table);
        this.token = new _floatToken();
    }

    public _float(String field, _table table, _fieldToken costomToken) {
        super(field, table, costomToken);
    }

    public void value(Double o)
    {
        //Console.WriteLine(o);
        val = o;
    }

    public Double value() {
        if (val == null) {
            return null;
        }
        return (Double)val;
    }

    public _expr equal(double v) {
        return new _expr(this, " = " + v);
    }
    public _expr notEqual(double v) {
        return new _expr(this, " != " + v);
    }
    public _expr great(double v) {
        return new _expr(this, " > " + v);
    }
    public _expr greatEqual(double v) {
        return new _expr(this, " >= " + v);
    }
    public _expr less(double v) {
        return new _expr(this, " < " + v);
    }
    public _expr lessEqual(double v) {
        return new _expr(this, " <= " + v);
    }

    public _expr between(double v1, double v2) {
        return new _expr(this, " BETWEEN " + v1 + " AND " + v2);
    }

    public class _floatToken implements _fieldToken {
        public String getValueToken(_field f) {
            if (f.val == null) {
                return "NULL";
            }
            return  f.val.toString();
        }
        public String selectAlias(_field f, String tableAlias) {
            return tableAlias + "." + f.field;
        }
        public String selectAlias(_field f) {
            return f.field;
        }
        public void setValue(String v, _field f){
            if(v==null){
                f.val = null;
            }
            else{
                f.val = Double.valueOf(v);
            }
        }
    }

    public _float max()  {
        _float f = new _float(this.field, this.table, new _customToken("MAX"));
        return f;
    }

    public _float min() {
        _float f = new _float(this.field, this.table, new _customToken("MIN"));
        return f;
    }

    public static boolean isFloat(String floatStr)
    {
//        System.Text.RegularExpressions.Regex rgxInt = new System.Text.RegularExpressions.Regex("(^[0-9]+$)|(^[0-9]+\\.[0-9]*$)|(^[0-9]*\\.[0-9]+$)");
//        return rgxInt.IsMatch(floatStr);
        return floatStr.matches("(^[0-9]+$)|(^[0-9]+\\.[0-9]*$)|(^[0-9]*\\.[0-9]+$)");
    }

}
