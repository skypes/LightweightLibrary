/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

/**
 *
 * @author Administrator
 */
public class _table {
    
    String schema = null;
    String table = null;
    public _field[] fieldList = null;

    public _table(String schema, String table) {
        this.schema = schema;
        this.table = table;
    }

    public String ConventionalName() {
        return schema + "." + table;
    }
}
