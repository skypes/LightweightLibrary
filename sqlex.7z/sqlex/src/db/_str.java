/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

/**
 *
 * @author Administrator
 */
public class _str extends _field {
   
    public _str(String field, _table table) {
        super(field, table);
        this.token = new _defaultToken();
    }

    public void value(String o) {
        //Console.WriteLine(o);
        val = o;
    }

    public String value() {
        //if (val == System.DBNull.Value) {
        //    return null;
        //}
        return (String)val;
    }

    //public new String valueToken() {
    //    if (val == null) {
    //        return "NULL";
    //    }
    //    return val.ToString();
    //}

    public _expr equal(String v) {
        return new _expr(this, " = '" + v.replaceAll("'", "''") + "'");
    }
    public _expr notEqual(String v) {
        return new _expr(this, " != '" + v.replaceAll("'", "''") + "'");
    }
    public _expr great(String v) {
        return new _expr(this, " > '" + v.replaceAll("'", "''") + "'");
    }
    public _expr greatEqual(String v) {
        return new _expr(this, " >= '" + v.replaceAll("'", "''") + "'");
    }
    public _expr less(String v) {
        return new _expr(this, " < '" + v.replaceAll("'", "''") + "'");
    }
    public _expr lessEqual(String v) {
        return new _expr(this, " <= '" + v.replaceAll("'", "''") + "'");
    }

    public _expr like(String v) {
        return new _expr(this, " LIKE '" + v.replaceAll("'", "''") + "'");
    }

    public _expr between(String v1, String v2) {
        return new _expr(this, " BETWEEN '" + v1.replaceAll("'", "''") + "' AND '" + v2.replaceAll("'", "''") + "'");
    }
 
}
