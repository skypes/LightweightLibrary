/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

/**
 *
 * @author Administrator
 */
public class _sqlExpress {
    
    public _field[] fieldList = null;
    _expr exp = null;
    _expr joinExp = null;
    _expr groupByExp = null;
    _expr orderByExp = null;

    boolean isDistinct = false;

    //public _sqlExpress select(_table t) {
    //    fieldList = t.fieldList;
    //    return this;
    //}

    public _sqlExpress select(_field[] fList, boolean isDistinct) {
        this.isDistinct = isDistinct;
        fieldList = fList;
        return this;
    }

    public _sqlExpress from(_table t) {
        joinExp = new _expr("FROM", t);
        return this;
    }

    public _sqlExpress innerJoin(_table t, _expr e1) { //INNER JOIN sys.objects AS o ON o.object_id = c.object_id
        joinExp = new _expr(joinExp, "INNER JOIN", t, "ON", e1);
        return this;
    }

    public _sqlExpress leftJoin(_table t, _expr e1) { //LEFT JOIN sys.types AS t on t.user_type_id = c.user_type_id
        joinExp = new _expr(joinExp, "LEFT JOIN", t, "ON", e1);
        return this;
    }

    public _sqlExpress where(_expr e1) {
        exp = e1;
        return this;
    }

    public _sqlExpress groupBy(_field[] fList) {
        groupByExp = new _expr("GROUP BY", fList[0]);
        for (int i = 1; i < fList.length; i++) {
            groupByExp = new _expr(groupByExp, ",", fList[i]);
        }
        return this;
    }

    public _sqlExpress orderBy(_field f, boolean isDESC) {
        if (isDESC) {
            orderByExp = new _expr("ORDER BY", f, "DESC");
        }
        else {
            orderByExp = new _expr("ORDER BY", f);
        }
        return this;
    }

    public _sqlExpress orderBy(_field[] fList, boolean[] isDESC) {
        if (isDESC[0]) {
            orderByExp = new _expr("ORDER BY", fList[0], "DESC");
        }
        else { 
            orderByExp = new _expr("ORDER BY", fList[0]);
        }

        for (int i=1; i< fList.length; i++) {
            if (isDESC[i]) {
                orderByExp = new _expr(orderByExp, ",", fList[i], "DESC");
            }
            else { 
                orderByExp = new _expr(orderByExp, ",", fList[i]);
            }
        }
        return this;
    }

    public String toSqlString() throws Exception {
        java.util.HashMap<_table, String> tbMap = new java.util.HashMap<>();
        StringBuilder whereSb = new StringBuilder();
        if (joinExp != null) {
            whereSb.append(joinExp.toSqlExpress(tbMap)).append(" ");
        }
        if (exp != null) {
            whereSb.append("WHERE ").append(exp.toSqlExpress(tbMap));
        }
        //Console.WriteLine("###########  tbMap.Count = " + tbMap.Count);
        StringBuilder selectSb = new StringBuilder("SELECT ");
        if (isDistinct) {
            selectSb.append("DISTINCT ");
        }
        if (tbMap.size() == 0) {
            selectSb.append(fieldList[0].selectToken());
            for (int i = 1; i < fieldList.length; i++) {
                selectSb.append(", ").append(fieldList[i].selectToken());
            }
            selectSb.append(" FROM ").append(fieldList[0].table.ConventionalName());

        }
        else {
            String tab = "";
            //Dictionary<_table, String> tbEtityMap = new Dictionary<_table, String>();
            for (int i = 0; i < fieldList.length; i++) {
                //if (!tbEtityMap.ContainsKey(fieldList[i].table)) {
                //    tbEtityMap[fieldList[i].table] = fieldList[i].table.ConventionalName();
                //}
                if (!tbMap.containsKey(fieldList[i].table)) {
                    throw new Exception("sqlex::_sqlExpress::toSqlString(): Inconsistent number of selected tables in the query");
                    //throw new Exception("#####"+ fieldList[0].table.ConventionalName());
                }
                selectSb.append(tab).append(fieldList[i].selectToken(tbMap.get(fieldList[i].table)));
                //selectSb.Append(tab).Append(tbMap[fieldList[0].table.GetHashCode()]).Append(".").Append(fieldList[i].field);
                tab = ",";
            }
            if (joinExp == null) { 
                tab = " FROM "; 
                for (_table k : tbMap.keySet()) {
                    selectSb.append(tab).append(k.ConventionalName()).append(" AS ").append(tbMap.get(k));
                    tab = ", ";
                }
            }
        }
        selectSb.append(" ").append(whereSb);
        if (groupByExp != null)  {
            if (tbMap.size() == 0) {
                selectSb.append(" ").append(groupByExp.toSqlExpress());
            }
            else {
                selectSb.append(" ").append(groupByExp.toSqlExpress(tbMap));
            }
        }
        if (orderByExp != null) {
            if (tbMap.size() == 0) {
                selectSb.append(" ").append(orderByExp.toSqlExpress());
            }
            else {
                selectSb.append(" ").append(orderByExp.toSqlExpress(tbMap));
            }
        }
        return selectSb.toString();
    }

    public String toSqlString(int begin, int end) throws Exception {
        java.util.HashMap<_table, String> tbMap = new java.util.HashMap<>();
        StringBuilder whereSb = new StringBuilder();
        if (joinExp != null) {
            whereSb.append(joinExp.toSqlExpress(tbMap)).append(" ");
        }
        if (exp != null) {
            whereSb.append("WHERE ").append(exp.toSqlExpress(tbMap));
        }
        //Console.WriteLine("###########  tbMap.Count = " + tbMap.Count);
        StringBuilder selectSb = new StringBuilder("SELECT ");
        if (isDistinct) {
            selectSb.append("DISTINCT ");
        }
        if (tbMap.size() == 0) {
            selectSb.append(fieldList[0].selectToken());
            for (int i = 1; i < fieldList.length; i++) {
                selectSb.append(", ").append(fieldList[i].selectToken());
            }
            selectSb.append(" FROM ").append(fieldList[0].table.ConventionalName());

        }
        else {
            String tab = "";
            //Dictionary<_table, String> tbEtityMap = new Dictionary<_table, String>();
            for (int i = 0; i < fieldList.length; i++) {
                //if (!tbEtityMap.ContainsKey(fieldList[i].table)) {
                //    tbEtityMap[fieldList[i].table] = fieldList[i].table.ConventionalName();
                //}
                if (!tbMap.containsKey(fieldList[i].table)) {
                    throw new Exception("sqlex::_sqlExpress::toSqlString(): Inconsistent number of selected tables in the query");
                    //throw new Exception("#####"+ fieldList[0].table.ConventionalName());
                }
                selectSb.append(tab).append(fieldList[i].selectToken(tbMap.get(fieldList[i].table)));
                //selectSb.Append(tab).Append(tbMap[fieldList[0].table.GetHashCode()]).Append(".").Append(fieldList[i].field);
                tab = ",";
            }
            if (joinExp == null) { 
                tab = " FROM "; 
                for (_table k : tbMap.keySet()) {
                    selectSb.append(tab).append(k.ConventionalName()).append(" AS ").append(tbMap.get(k));
                    tab = ", ";
                }
            }
        }
        selectSb.append(" ").append(whereSb);
        if (groupByExp != null)  {
            if (tbMap.size() == 0) {
                selectSb.append(" ").append(groupByExp.toSqlExpress());
            }
            else {
                selectSb.append(" ").append(groupByExp.toSqlExpress(tbMap));
            }
        }
        if (orderByExp != null) {
            if (tbMap.size() == 0) {
                selectSb.append(" ").append(orderByExp.toSqlExpress());
            }
            else {
                selectSb.append(" ").append(orderByExp.toSqlExpress(tbMap));
            }
        }
        selectSb.append(" LIMIT ").append(String.valueOf(begin)).append(", ").append(String.valueOf(end));
        return selectSb.toString();
    }
    
    public static String getInsertSql(_table t) {
        StringBuilder insertSb = new StringBuilder();
        StringBuilder valueSb = new StringBuilder();
        insertSb.append("INSERT INTO ").append(t.ConventionalName()).append("(");
        String tab = "";
        for (int i=0; i<t.fieldList.length; i++) {
            if (t.fieldList[i].val == null) {
                continue;
            }
//            System.out.println("11111111111111111111111111111111111111 --> "+t.fieldList[i].field);
            insertSb.append(tab).append(t.fieldList[i].field);
            valueSb.append(tab).append(t.fieldList[i].valueToken());
            tab = ",";
//            System.out.println("222222222222222222222222222 --> "+t.fieldList[i].field);
        }
//            System.out.println("2222222222222222 --> ");
        insertSb.append(") VALUES(").append(valueSb).append(")");

        return insertSb.toString();
    }

    public static String getUpdateSql(_table t, _expr e) {
        StringBuilder updateSb = new StringBuilder();
        updateSb.append("UPDATE ").append(t.ConventionalName()).append(" SET ");
        String tab = "";
        for (int i = 0; i < t.fieldList.length; i++) {
            if (t.fieldList[i].val == null) {
                continue;
            }
            updateSb.append(tab).append(t.fieldList[i].field).append("=").append(t.fieldList[i].valueToken());
            tab = ",";
        }
        updateSb.append(" WHERE ").append(e.toSqlExpress());
        return updateSb.toString();
    }

    public static String getUpdateSqlWithNull(_table t, _expr e) {
        StringBuilder updateSb = new StringBuilder();
        updateSb.append("UPDATE ").append(t.ConventionalName()).append(" SET ");
        String tab = "";
        for (int i = 0; i < t.fieldList.length; i++) {
            updateSb.append(tab).append(t.fieldList[i].field).append("=").append(t.fieldList[i].valueToken());
            tab = ",";
        }
        updateSb.append(" WHERE ").append(e.toSqlExpress());
        return updateSb.toString();
    }

    public static String getDeleteSql(_expr e) {
        java.util.HashMap<_table, String> aMap = new java.util.HashMap<>();
        e.toSqlExpress(aMap);
        _table t = aMap.keySet().iterator().next();
//        System.out.println(aMap.keySet().iterator().next());
        StringBuilder deleteSb = new StringBuilder();
        deleteSb.append("DELETE FROM ").append(t.ConventionalName());
        deleteSb.append(" WHERE ").append(e.toSqlExpress());
        return deleteSb.toString();
    }
    
    public static String getTruncateSql(_table t) {
        StringBuilder deleteSb = new StringBuilder();
        deleteSb.append("TRUNCATE TABLE ").append(t.ConventionalName());
        return deleteSb.toString();
    }
    
}
