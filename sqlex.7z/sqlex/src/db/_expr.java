/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

/**
 *
 * @author Administrator
 */
public class _expr {

    _expressToken token;

    public _expr(_field f1, String op, _field f2) {
        token = new _token_f_op_f(f1, op, f2);
    }

    public _expr(_field f1, String op) {
        token = new _token_f_op(f1, op);
    }

    public _expr(String op, _field f1) {
        token = new _token_op_f(op, f1);
    }

    public _expr(String op, _field f1, String op2) {
        token = new _token_op_f_op(op, f1, op2);
    }

    public _expr(String op, _table t1) {
        token = new _token_o_t(op, t1);
    }

    public _expr(_expr e1) {
        token = new _token_e(e1);
    }

    public _expr(_expr e, String op, _field f1)
    {
        token = new _token_e_op_f(e, op, f1);
    }

    public _expr(_expr e, String op, _field f1, String op2)
    {
        token = new _token_e_op_f_op(e, op, f1, op2);
    }

    public _expr(_expr e1, String op, _expr e2) {
        token = new _token_e_op_e(e1, op, e2);
    }

    public _expr(_expr e, String op, _table t1, String op2, _expr e1) {
        token = new _token_e_o_t_o_e(e, op, t1, op2, e1);
    }

    /// <summary>
    /// /////////////////////////////////////
    /// /////////////////////////////////////
    /// </summary>
    /// <param name="e2"></param>
    /// <returns></returns>
    public _expr and(_expr e2) {
        return new _expr(this, "AND" , e2);
    }

    public _expr or(_expr e2)
    {
        return new _expr(this, "OR", e2);
    }

    public _expr andWithBrackets(_expr e2) {
        return new _expr(new _expr(this), "AND", new _expr(e2));
    }

    public _expr orWithBrackets(_expr e2) {
        return new _expr(new _expr(this), "OR", new _expr(e2));
    }

    public String toSqlExpress(java.util.HashMap<_table, String> aMap) {
        return token.getExpress(aMap);
    }

    public String toSqlExpress()
    {
        return token.getExpress();
    }

    public interface _expressToken
    {
        String getExpress(java.util.HashMap<_table, String> aMap);
        String getExpress();
    }

    public class _token_f_op_f implements _expressToken {
        _field f1;
        String op;
        _field f2;

        public _token_f_op_f(_field f1, String op, _field f2) {
            this.f1 = f1;
            this.op = op;
            this.f2 = f2;
        }

        public String getExpress(java.util.HashMap<_table, String> aMap) {
            //int h1 = f1.table.GetHashCode();
            //int h2 = f2.table.GetHashCode();
            if (!aMap.containsKey(f1.table)) {
                aMap.put(f1.table, "T" + aMap.size());
            }
            if (!aMap.containsKey(f2.table)) {
                aMap.put(f2.table, "T" + aMap.size());
            }
            //return aMap[h1] + "." + f1.field + " " + op + " " + aMap[h2] + "." + f2.field;
            return f1.selectToken(aMap.get(f1.table)) + " " + op + " " + f2.selectToken(aMap.get(f2.table));
        }

        public String getExpress() {
            return f1.selectToken() + " " + op + " " + f2.selectToken();
        }

    }

    public class _token_f_op implements _expressToken {
        _field f1;
        String op;

        public _token_f_op(_field f1, String op) {
            this.f1 = f1;
            this.op = op;
        }

        public String getExpress(java.util.HashMap<_table, String> aMap) {
            //int h1 = f1.table.GetHashCode();
            if (!aMap.containsKey(f1.table)) {
                aMap.put(f1.table, "T" + aMap.size());
            }
            return f1.selectToken(aMap.get(f1.table)) + " " + op;
        }

        public String getExpress() {
            return f1.selectToken() + " " + op;
        }

    }

    public class _token_op_f implements _expressToken {
        _field f1;
        String op;

        public _token_op_f(String op, _field f1) {
            this.f1 = f1;
            this.op = op;
        }

        public String getExpress(java.util.HashMap<_table, String> aMap) {
            //int h1 = f1.table.GetHashCode();
            if (!aMap.containsKey(f1.table)) {
                aMap.put(f1.table, "T" + aMap.size());
            }
            return op + " " + f1.selectToken(aMap.get(f1.table));
        }

        public String getExpress() {
            return op+" "+f1.selectToken();
        }

    }

    public class _token_op_f_op implements _expressToken
    {
        _field f1;
        String op;
        String op2;

        public _token_op_f_op(String op, _field f1, String op2) {
            this.f1 = f1;
            this.op = op;
            this.op2 = op2;
        }

        public String getExpress(java.util.HashMap<_table, String> aMap) {
            //int h1 = f1.table.GetHashCode();
            if (!aMap.containsKey(f1.table)) {
                aMap.put(f1.table, "T" + aMap.size());
            }
            return op + " " + f1.selectToken(aMap.get(f1.table)) + " "+op2;
        }

        public String getExpress() {
            return op + " " + f1.selectToken() + " "+op2;
        }

    }

    public class _token_e_op_e implements _expressToken {
        _expr e1;
        String op;
        _expr e2;

        public _token_e_op_e(_expr e1, String op, _expr e2) {
            this.e1 = e1;
            this.op = op;
            this.e2 = e2;
        }

        public String getExpress(java.util.HashMap<_table, String> aMap) {
            return e1.toSqlExpress(aMap) + " " + op + " " + e2.toSqlExpress(aMap);
        }

        public String getExpress() {
            return e1.toSqlExpress() + " " + op + " " + e2.toSqlExpress();
        }

    }

    public class _token_e_op_f implements _expressToken
    {
        _expr e1;
        String op;
        _field f1;

        public _token_e_op_f(_expr e1, String op, _field f1)
        {
            this.e1 = e1;
            this.op = op;
            this.f1 = f1;
        }

        public String getExpress(java.util.HashMap<_table, String> aMap)
        {
            //int h1 = f1.table.GetHashCode();
            if (!aMap.containsKey(f1.table))
            {
                aMap.put(f1.table, "T" + aMap.size());
            }
            return e1.toSqlExpress(aMap) + " " + op + " " + f1.selectToken(aMap.get(f1.table));
        }

        public String getExpress()
        {
            return e1.toSqlExpress() + " " + op + " " + f1.selectToken();
        }

    }

    public class _token_e_op_f_op implements _expressToken
    {
        _expr e1;
        _field f1;
        String op;
        String op2;

        public _token_e_op_f_op(_expr e1, String op, _field f1, String op2)
        {
            this.e1 = e1;
            this.f1 = f1;
            this.op = op;
            this.op2 = op2;
        }

        public String getExpress(java.util.HashMap<_table, String> aMap)
        {
            //int h1 = f1.table.GetHashCode();
            if (!aMap.containsKey(f1.table)) {
                aMap.put(f1.table, "T" + aMap.size());
            }
            return e1.toSqlExpress(aMap) + " " + op + " " + f1.selectToken(aMap.get(f1.table)) + " " + op2;
        }

        public String getExpress() {
            return e1.toSqlExpress() + " " + op + " " + f1.selectToken() + " " + op2;
        }

    }

    public class _token_e implements _expressToken {
        _expr e1;

        public _token_e(_expr e1) {
            this.e1 = e1;
        }

        public String getExpress(java.util.HashMap<_table, String> aMap) {
            return "(" + e1.toSqlExpress(aMap) + ")";
        }

        public String getExpress() {
            return "(" + e1.toSqlExpress() + ")";
        }

    }

    public class _token_o_t implements _expressToken {
        _table t1;
        String op;

        public _token_o_t(String op, _table t1)
        {
            this.op = op;
            this.t1 = t1;
        }

        public String getExpress(java.util.HashMap<_table, String> aMap) {
            //int h1 = t1.GetHashCode();
            if (!aMap.containsKey(t1)) {
                aMap.put(t1, "T" + aMap.size());
            }
            return op + " " + t1.ConventionalName() + " AS "+ aMap.get(t1);
        }

        public String getExpress() {
            return op + " " + t1.ConventionalName();
        }

    }

    public class _token_e_o_t_o_e implements _expressToken {
        _expr e;
        String op;
        _table t1;
        String op2;
        _expr e1;

        public _token_e_o_t_o_e(_expr e, String op, _table t1, String op2, _expr e1) {
            this.e = e;
            this.op = op;
            this.t1 = t1;
            this.op2 = op2;
            this.e1 = e1;
        }

        public String getExpress(java.util.HashMap<_table, String> aMap) {
            //int h1 = t1.GetHashCode();
            if (!aMap.containsKey(t1)) {
                aMap.put(t1, "T" + aMap.size());
            }
            return e.toSqlExpress(aMap) + " " + op + " " + t1.ConventionalName() + " AS " + aMap.get(t1) +" "+op2+" "+ e1.toSqlExpress(aMap);
        }

        public String getExpress() {
            return e.toSqlExpress() + " " + op + " " + t1.ConventionalName() + " " + op2 + " " + e1.toSqlExpress();
        }

    }

}
